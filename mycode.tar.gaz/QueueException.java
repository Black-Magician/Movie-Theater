
// TODO: Auto-generated Javadoc
/**
 * The Class QueueException.
 */
public class QueueException extends RuntimeException
{

    /**
     * Instantiates a new queue exception.
     *
     * @param s the s
     */
    public QueueException(String s)
    {
        super(s);
    }
}
