
// TODO: Auto-generated Javadoc
/**
 * The Class TooManyPeopleException.
 */
public class TooManyPeopleException extends RuntimeException
{

    /**
     * Instantiates a new too many people exception.
     *
     * @param s the s
     */
    public TooManyPeopleException(String s)
    {
        super(s);
    }
}
